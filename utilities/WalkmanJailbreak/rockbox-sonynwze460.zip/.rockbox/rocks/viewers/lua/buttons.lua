-- Don't change this file!
-- It is automatically generated of button.h $Revision$
rb.buttons = {
	BUTTON_UP = 16,
	BUTTON_VOL_DOWN = 128,
	BUTTON_POWER = 1,
	BUTTON_DOWN = 32,
	BUTTON_LEFT = 8,
	BUTTON_RIGHT = 64,
	BUTTON_MAIN = 511,
	BUTTON_BACK = 2,
	BUTTON_PLAY = 4,
	BUTTON_VOL_UP = 256,
	BUTTON_REL = 33554432,
	BUTTON_REPEAT = 67108864,
	BUTTON_TOUCHSCREEN = 134217728,
}
